HUE TRAVEL - CoSoLuuTru v4 - 38 co so luu tru, POINT, WGS84 EPSG:4326.
GiaVND va GiaTK la gia quy uoc tham khao theo LoaiCS, KHONG phai gia duoc khach san niem yet.
24 diem cu giu nguyen, 14 diem mo rong, toa do lay theo URL cua KiemChung_Nguon trong Excel.
Khi routing can kiem tra cong vao va snap den doan duong gan nhat.
Nguon mo: OpenStreetMap contributors / ODbL https://www.openstreetmap.org/copyright
